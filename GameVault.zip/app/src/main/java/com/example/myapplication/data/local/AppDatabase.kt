package com.example.myapplication.data.local

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.io.File

internal class AppDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    File(context.noBackupFilesDir, "gamevault.db").absolutePath,
    null,
    4
) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE usuarios(
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL CHECK(length(nome) BETWEEN 3 AND 100),
            email TEXT NOT NULL UNIQUE CHECK(length(email) BETWEEN 3 AND 254),
            senha BLOB NOT NULL,
            salt BLOB NOT NULL,
            cep TEXT,
            logradouro TEXT,
            bairro TEXT,
            cidade TEXT,
            uf TEXT
            )
            """.trimIndent()
        )
        criarTabelaJogos(db)
        criarTabelaLojas(db)
        criarTabelasExtras(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            criarTabelaJogos(db)
            JogosIniciais.inserirParaTodos(db)
        }
        if (oldVersion < 3) {
            criarTabelasExtras(db)
        }
        if (oldVersion < 4) {
            adicionarColunasDeEndereco(db)
            db.execSQL("DROP TABLE IF EXISTS lojas")
            criarTabelaLojas(db)
            LojasIniciais.inserirParaTodos(db)
        }
    }

    private fun criarTabelaJogos(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE jogos(
            id INTEGER PRIMARY KEY,
            usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            titulo TEXT NOT NULL CHECK(length(titulo) BETWEEN 2 AND 100),
            plataforma TEXT NOT NULL,
            horas INTEGER NOT NULL CHECK(horas >= 0),
            status TEXT NOT NULL CHECK(status IN ('JOGANDO', 'PROXIMO', 'CONCLUIDO')),
            genero TEXT NOT NULL,
            desenvolvedora TEXT NOT NULL,
            nota INTEGER NOT NULL CHECK(nota BETWEEN 0 AND 5),
            capa_recurso TEXT,
            capa_arquivo TEXT
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_jogos_usuario ON jogos(usuario_id)")
    }

    private fun adicionarColunasDeEndereco(db: SQLiteDatabase) {
        db.execSQL("ALTER TABLE usuarios ADD COLUMN cep TEXT")
        db.execSQL("ALTER TABLE usuarios ADD COLUMN logradouro TEXT")
        db.execSQL("ALTER TABLE usuarios ADD COLUMN bairro TEXT")
        db.execSQL("ALTER TABLE usuarios ADD COLUMN cidade TEXT")
        db.execSQL("ALTER TABLE usuarios ADD COLUMN uf TEXT")
    }

    private fun criarTabelaLojas(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE lojas(
            id INTEGER PRIMARY KEY,
            usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            nome TEXT NOT NULL CHECK(length(nome) BETWEEN 2 AND 100),
            endereco TEXT NOT NULL CHECK(length(endereco) BETWEEN 5 AND 200),
            descricao TEXT NOT NULL,
            foto_arquivo TEXT
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_lojas_usuario ON lojas(usuario_id)")
    }

    private fun criarTabelasExtras(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE desejos(
            id INTEGER PRIMARY KEY,
            usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            titulo TEXT NOT NULL CHECK(length(titulo) BETWEEN 2 AND 100),
            plataforma TEXT NOT NULL,
            prioridade INTEGER NOT NULL CHECK(prioridade BETWEEN 1 AND 3)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_desejos_usuario ON desejos(usuario_id)")

        db.execSQL(
            """
            CREATE TABLE anotacoes(
            id INTEGER PRIMARY KEY,
            jogo_id INTEGER NOT NULL REFERENCES jogos(id) ON DELETE CASCADE,
            texto TEXT NOT NULL CHECK(length(texto) BETWEEN 1 AND 500)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_anotacoes_jogo ON anotacoes(jogo_id)")
    }
}
