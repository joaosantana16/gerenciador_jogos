package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.model.Anotacao
import com.example.myapplication.ui.components.Estrelas
import com.example.myapplication.ui.components.ImagemCapa
import com.example.myapplication.ui.components.SeloDeStatus
import com.example.myapplication.ui.components.coresDoCampo
import com.example.myapplication.ui.theme.BotaoEditarFundo
import com.example.myapplication.ui.theme.BotaoRemoverFundo
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.TextGray
import com.example.myapplication.ui.theme.VermelhoRemover
import com.example.myapplication.ui.viewmodel.AnotacaoViewModel
import com.example.myapplication.ui.viewmodel.JogoViewModel

@Composable
fun DetalhesJogoScreen(
    jogoId: Int,
    jogoViewModel: JogoViewModel,
    anotacaoViewModel: AnotacaoViewModel,
    irParaEdicao: (Int) -> Unit,
    voltar: () -> Unit
) {

    var confirmarRemocao by remember { mutableStateOf(false) }

    var removendo by remember { mutableStateOf(false) }

    var mostrarDialogoAnotacao by remember { mutableStateOf(false) }
    var anotacaoEditando by remember { mutableStateOf<Anotacao?>(null) }

    LaunchedEffect(jogoId) { anotacaoViewModel.carregar(jogoId) }

    val jogo = jogoViewModel.buscarPorId(jogoId)

    if (jogo == null) {

        if (!removendo) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Jogo não encontrado.", color = Color.White)
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = voltar) { Text("Voltar") }
            }
        }
        return
    }

    val subtitulo = listOf(jogo.desenvolvedora, jogo.genero)
        .filter { it.isNotBlank() }
        .joinToString(" | ")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 24.dp)
    ) {
        Text(
            text = "DETALHES DO JOGO",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp),
            shape = RoundedCornerShape(20.dp)
        ) {
            ImagemCapa(
                capa = jogo.capa,
                capaArquivo = jogo.capaArquivo,
                descricao = "Capa do jogo ${jogo.titulo}",
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = jogo.titulo.uppercase(),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            SeloDeStatus(jogo.status)
        }

        if (subtitulo.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = subtitulo, color = TextGray, fontSize = 14.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CaixaInfo(
                titulo = "Plataforma",
                valor = jogo.plataforma,
                modifier = Modifier.weight(1f)
            )
            CaixaInfo(
                titulo = "Horas jogadas",
                valor = "${jogo.horas}h",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Nota:",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Estrelas(nota = jogo.nota)

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { irParaEdicao(jogo.id) },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BotaoEditarFundo,
                    contentColor = Color.White
                )
            ) {
                Text("Editar")
            }

            Button(
                onClick = { confirmarRemocao = true },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BotaoRemoverFundo,
                    contentColor = VermelhoRemover
                )
            ) {
                Text("Remover")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ANOTAÇÕES",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            TextButton(
                onClick = {
                    anotacaoViewModel.limparMensagem()
                    anotacaoEditando = null
                    mostrarDialogoAnotacao = true
                }
            ) {
                Text("Nova anotação")
            }
        }

        if (anotacaoViewModel.anotacoes.isEmpty()) {
            Text("Nenhuma anotação ainda.", color = TextGray, fontSize = 14.sp)
        }

        anotacaoViewModel.anotacoes.forEach { anotacao ->
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardDark)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = anotacao.texto, color = Color.White, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = {
                                anotacaoViewModel.limparMensagem()
                                anotacaoEditando = anotacao
                                mostrarDialogoAnotacao = true
                            }
                        ) { Text("Editar") }
                        TextButton(
                            onClick = { anotacaoViewModel.remover(anotacao.id, jogo.id) }
                        ) { Text("Remover", color = VermelhoRemover) }
                    }
                }
            }
        }
    }

    if (mostrarDialogoAnotacao) {
        DialogoAnotacao(
            anotacaoViewModel = anotacaoViewModel,
            anotacao = anotacaoEditando,
            jogoId = jogo.id,
            aoFechar = { mostrarDialogoAnotacao = false }
        )
    }

    if (confirmarRemocao) {
        AlertDialog(
            onDismissRequest = { confirmarRemocao = false },
            containerColor = CardDark,
            titleContentColor = Color.White,
            textContentColor = TextGray,
            title = { Text("Remover jogo?") },
            text = { Text("Remover \"${jogo.titulo}\" da sua biblioteca? Esta ação não pode ser desfeita.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmarRemocao = false
                        removendo = true
                        jogoViewModel.remover(jogo.id)
                        voltar()
                    }
                ) { Text("Remover", color = VermelhoRemover) }
            },
            dismissButton = {
                TextButton(onClick = { confirmarRemocao = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun CaixaInfo(titulo: String, valor: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardDark)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = titulo, color = TextGray, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = valor,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }
    }
}

@Composable
private fun DialogoAnotacao(
    anotacaoViewModel: AnotacaoViewModel,
    anotacao: Anotacao?,
    jogoId: Int,
    aoFechar: () -> Unit
) {
    var texto by remember { mutableStateOf(anotacao?.texto ?: "") }

    LaunchedEffect(anotacaoViewModel.concluido) {
        if (anotacaoViewModel.concluido) {
            anotacaoViewModel.consumirConclusao()
            aoFechar()
        }
    }

    AlertDialog(
        onDismissRequest = aoFechar,
        containerColor = CardDark,
        titleContentColor = Color.White,
        textContentColor = TextGray,
        title = { Text(if (anotacao == null) "Nova anotação" else "Editar anotação") },
        text = {
            Column {
                OutlinedTextField(
                    value = texto,
                    onValueChange = { if (it.length <= 500) texto = it },
                    label = { Text("Anotação") },
                    minLines = 3,
                    colors = coresDoCampo(),
                    modifier = Modifier.fillMaxWidth()
                )
                anotacaoViewModel.mensagem?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (anotacao == null) {
                        anotacaoViewModel.adicionar(jogoId, texto)
                    } else {
                        anotacaoViewModel.atualizar(anotacao.id, jogoId, texto)
                    }
                },
                enabled = !anotacaoViewModel.processando
            ) { Text("Salvar") }
        },
        dismissButton = {
            TextButton(onClick = aoFechar) { Text("Cancelar") }
        }
    )
}
