package com.example.myapplication.data.local

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

internal object ArmazenamentoImagem {
    private const val LADO_MAXIMO = 1024

    private fun pasta(context: Context) = File(context.filesDir, "capas").apply { mkdirs() }

    fun salvarCapa(context: Context, uri: Uri): String {
        val resolver = context.contentResolver

        val limites = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, limites) }
        require(limites.outWidth > 0 && limites.outHeight > 0) { "Não foi possível ler essa imagem." }

        var amostra = 1
        while (limites.outWidth / amostra > LADO_MAXIMO || limites.outHeight / amostra > LADO_MAXIMO) {
            amostra *= 2
        }

        val opcoes = BitmapFactory.Options().apply { inSampleSize = amostra }
        val lida = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opcoes) }
            ?: throw IllegalArgumentException("Não foi possível ler essa imagem.")

        val graus = runCatching {
            resolver.openInputStream(uri)?.use { entrada ->
                when (ExifInterface(entrada).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        }.getOrDefault(0f)

        val bitmap = if (graus != 0f) {
            val matriz = Matrix().apply { postRotate(graus) }
            Bitmap.createBitmap(lida, 0, 0, lida.width, lida.height, matriz, true).also { lida.recycle() }
        } else {
            lida
        }

        val arquivo = File(pasta(context), "capa_${System.currentTimeMillis()}.jpg")
        FileOutputStream(arquivo).use { saida ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, saida)
        }
        bitmap.recycle()
        return arquivo.absolutePath
    }

    fun apagar(caminho: String?) {
        if (caminho != null) File(caminho).delete()
    }
}
