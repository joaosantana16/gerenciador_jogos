package com.example.myapplication.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.auth.SessaoUsuario
import com.example.myapplication.data.dal.DesejoDao
import com.example.myapplication.data.model.Desejo
import com.example.myapplication.validation.DesejoValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DesejoViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = DesejoDao(application)

    var desejos by mutableStateOf<List<Desejo>>(emptyList())
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set
    var processando by mutableStateOf(false)
        private set
    var concluido by mutableStateOf(false)
        private set

    fun carregar() {
        val usuarioId = SessaoUsuario.usuarioId ?: return

        viewModelScope.launch {
            try {
                desejos = withContext(Dispatchers.IO) { dao.listar(usuarioId) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                mensagem = "Não foi possível carregar a lista de desejos."
            }
        }
    }

    private fun executar(op: suspend () -> Unit) {
        if (processando) return
        processando = true
        mensagem = null

        viewModelScope.launch {
            try {
                op()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                mensagem = e.message
            } catch (e: Exception) {
                mensagem = "Ocorreu um erro inesperado."
            } finally {
                processando = false
            }
        }
    }

    fun adicionar(titulo: String, plataforma: String, prioridade: Int) = executar {
        DesejoValidator.validar(titulo, plataforma, prioridade)
        val usuarioId = SessaoUsuario.exigirUsuario()

        desejos = withContext(Dispatchers.IO) {
            dao.inserir(usuarioId, Desejo(0, titulo.trim(), plataforma, prioridade))
            dao.listar(usuarioId)
        }
        concluido = true
    }

    fun atualizar(id: Int, titulo: String, plataforma: String, prioridade: Int) = executar {
        DesejoValidator.validar(titulo, plataforma, prioridade)
        val usuarioId = SessaoUsuario.exigirUsuario()

        desejos = withContext(Dispatchers.IO) {
            dao.atualizar(usuarioId, Desejo(id, titulo.trim(), plataforma, prioridade))
            dao.listar(usuarioId)
        }
        concluido = true
    }

    fun remover(id: Int) = executar {
        val usuarioId = SessaoUsuario.exigirUsuario()

        desejos = withContext(Dispatchers.IO) {
            dao.remover(usuarioId, id)
            dao.listar(usuarioId)
        }
    }

    fun consumirConclusao() {
        concluido = false
    }

    fun limparMensagem() {
        mensagem = null
    }
}
