package com.example.myapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.R
import com.example.myapplication.data.model.Desejo
import com.example.myapplication.data.model.Endereco
import com.example.myapplication.data.model.PRIORIDADES
import com.example.myapplication.ui.components.OpcaoSelecionavel
import com.example.myapplication.ui.components.PlatformField
import com.example.myapplication.ui.components.coresDoCampo
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.PurpleAccent
import com.example.myapplication.ui.theme.TextGray
import com.example.myapplication.ui.theme.VermelhoRemover
import com.example.myapplication.ui.viewmodel.DesejoViewModel
import com.example.myapplication.ui.viewmodel.JogoViewModel
import com.example.myapplication.ui.viewmodel.PerfilViewModel

@Composable
fun PerfilScreen(
    jogoViewModel: JogoViewModel,
    perfilViewModel: PerfilViewModel,
    desejoViewModel: DesejoViewModel,
    aoSair: () -> Unit
) {

    LaunchedEffect(Unit) {
        perfilViewModel.carregar()
        desejoViewModel.carregar()
    }

    var mostrarDialogoDesejo by remember { mutableStateOf(false) }
    var desejoEditando by remember { mutableStateOf<Desejo?>(null) }
    var desejoRemovendo by remember { mutableStateOf<Desejo?>(null) }

    val usuario = perfilViewModel.usuario
    val nome = usuario?.nome ?: "..."

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .size(90.dp)
                .background(color = PurpleAccent, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = nome.first().uppercase(),
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = nome,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = usuario?.email ?: "",
            color = TextGray,
            fontSize = 13.sp
        )

        perfilViewModel.mensagem?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(16.dp))

        CartaoEndereco(endereco = usuario?.endereco ?: Endereco())

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "Jogos na estante",
                value = jogoViewModel.totalJogos.toString(),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Concluídos",
                value = jogoViewModel.concluidos.toString(),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard(
                title = "Horas totais",
                value = "${jogoViewModel.horasTotais}h",
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Gênero favorito",
                value = jogoViewModel.generoFavorito,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LISTA DE DESEJOS",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            TextButton(
                onClick = {
                    desejoViewModel.limparMensagem()
                    desejoEditando = null
                    mostrarDialogoDesejo = true
                }
            ) {
                Text("Adicionar")
            }
        }

        if (desejoViewModel.desejos.isEmpty()) {
            Text(
                text = "Nenhum jogo na lista de desejos.",
                color = TextGray,
                fontSize = 14.sp
            )
        }

        desejoViewModel.desejos.forEach { desejo ->
            Spacer(modifier = Modifier.height(8.dp))
            LinhaDesejo(
                desejo = desejo,
                aoEditar = {
                    desejoViewModel.limparMensagem()
                    desejoEditando = desejo
                    mostrarDialogoDesejo = true
                },
                aoRemover = { desejoRemovendo = desejo }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        MenuButton(
            text = "Sair",
            icon = painterResource(id = R.drawable.ic_sair),
            onClick = aoSair
        )

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (mostrarDialogoDesejo) {
        DialogoDesejo(
            desejoViewModel = desejoViewModel,
            desejo = desejoEditando,
            aoFechar = { mostrarDialogoDesejo = false }
        )
    }

    desejoRemovendo?.let { desejo ->
        AlertDialog(
            onDismissRequest = { desejoRemovendo = null },
            containerColor = CardDark,
            titleContentColor = Color.White,
            textContentColor = TextGray,
            title = { Text("Remover da lista?") },
            text = { Text("Remover \"${desejo.titulo}\" da sua lista de desejos?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        desejoViewModel.remover(desejo.id)
                        desejoRemovendo = null
                    }
                ) { Text("Remover", color = VermelhoRemover) }
            },
            dismissButton = {
                TextButton(onClick = { desejoRemovendo = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun CartaoEndereco(endereco: Endereco) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = CardDark, shape = RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text(text = "Meu endereço", color = TextGray, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))

        if (endereco.cep.isBlank()) {
            Text(text = "CEP não informado", color = Color.White, fontSize = 15.sp)
        } else {
            Text(
                text = "CEP ${endereco.cepFormatado}",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            if (endereco.ruaEBairro.isNotBlank()) {
                Text(text = endereco.ruaEBairro, color = Color.White, fontSize = 14.sp)
            }
            if (endereco.cidadeEUf.isNotBlank()) {
                Text(text = endereco.cidadeEUf, color = TextGray, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun LinhaDesejo(desejo: Desejo, aoEditar: () -> Unit, aoRemover: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = CardDark, shape = RoundedCornerShape(14.dp))
            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = desejo.titulo,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${desejo.plataforma} | Prioridade ${desejo.rotuloPrioridade}",
                color = TextGray,
                fontSize = 13.sp
            )
        }
        TextButton(onClick = aoEditar) { Text("Editar") }
        TextButton(onClick = aoRemover) { Text("Remover", color = VermelhoRemover) }
    }
}

@Composable
private fun DialogoDesejo(
    desejoViewModel: DesejoViewModel,
    desejo: Desejo?,
    aoFechar: () -> Unit
) {
    var titulo by remember { mutableStateOf(desejo?.titulo ?: "") }
    var plataforma by remember { mutableStateOf(desejo?.plataforma ?: "PC") }
    var prioridade by remember { mutableIntStateOf(desejo?.prioridade ?: 2) }

    LaunchedEffect(desejoViewModel.concluido) {
        if (desejoViewModel.concluido) {
            desejoViewModel.consumirConclusao()
            aoFechar()
        }
    }

    AlertDialog(
        onDismissRequest = aoFechar,
        containerColor = CardDark,
        titleContentColor = Color.White,
        textContentColor = TextGray,
        title = { Text(if (desejo == null) "Novo desejo" else "Editar desejo") },
        text = {
            Column {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { if (it.length <= 100) titulo = it },
                    label = { Text("Nome do jogo") },
                    singleLine = true,
                    colors = coresDoCampo(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                PlatformField(selected = plataforma, onSelected = { plataforma = it })
                Spacer(modifier = Modifier.height(12.dp))
                Text("Prioridade", color = TextGray, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PRIORIDADES.forEachIndexed { indice, rotulo ->
                        OpcaoSelecionavel(
                            texto = rotulo,
                            selecionada = prioridade == indice + 1,
                            modifier = Modifier.weight(1f)
                        ) { prioridade = indice + 1 }
                    }
                }
                desejoViewModel.mensagem?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (desejo == null) {
                        desejoViewModel.adicionar(titulo, plataforma, prioridade)
                    } else {
                        desejoViewModel.atualizar(desejo.id, titulo, plataforma, prioridade)
                    }
                },
                enabled = !desejoViewModel.processando
            ) { Text("Salvar") }
        },
        dismissButton = {
            TextButton(onClick = aoFechar) { Text("Cancelar") }
        }
    )
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(color = CardDark, shape = RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) {
        Text(text = title, color = TextGray, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = value,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun MenuButton(text: String, icon: Painter, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = CardDark, shape = RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 14.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painter = icon, contentDescription = text, tint = TextGray)
        Spacer(modifier = Modifier.width(12.dp))
        Text(text = text, color = Color.White, fontSize = 15.sp)
    }
}
