package com.example.myapplication.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.auth.SessaoUsuario
import com.example.myapplication.data.dal.LojaDao
import com.example.myapplication.data.local.ArmazenamentoImagem
import com.example.myapplication.data.model.Loja
import com.example.myapplication.validation.LojaValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LojaViewModel(application: Application) : AndroidViewModel(application) {
    private val contexto = application
    private val dao = LojaDao(application)

    var lojas by mutableStateOf<List<Loja>>(emptyList())
        private set
    var processando by mutableStateOf(false)
        private set
    var concluido by mutableStateOf(false)
        private set
    var erro by mutableStateOf<String?>(null)
        private set
    var aviso by mutableStateOf<String?>(null)
        private set

    private var usuarioCarregado: Long? = null

    fun carregar() {
        val usuarioId = SessaoUsuario.usuarioId ?: return
        if (usuarioId != usuarioCarregado) {
            lojas = emptyList()
            usuarioCarregado = usuarioId
        }

        viewModelScope.launch {
            try {
                lojas = withContext(Dispatchers.IO) { dao.listar(usuarioId) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                aviso = "Não foi possível carregar as lojas."
            }
        }
    }

    private fun executar(op: suspend () -> Unit) {
        if (processando) return
        processando = true
        erro = null

        viewModelScope.launch {
            try {
                op()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                erro = e.message
            } catch (e: Exception) {
                erro = "Ocorreu um erro inesperado."
            } finally {
                processando = false
            }
        }
    }

    fun adicionar(nome: String, endereco: String, descricao: String, foto: Uri?) = executar {
        LojaValidator.validar(nome, endereco, descricao)
        val usuarioId = SessaoUsuario.exigirUsuario()

        lojas = withContext(Dispatchers.IO) {
            val caminho = foto?.let { ArmazenamentoImagem.salvarCapa(contexto, it) }
            try {
                dao.inserir(
                    usuarioId,
                    Loja(0, nome.trim(), endereco.trim(), descricao.trim(), caminho)
                )
            } catch (e: Exception) {
                ArmazenamentoImagem.apagar(caminho)
                throw e
            }
            dao.listar(usuarioId)
        }
        aviso = "Loja adicionada."
        concluido = true
    }

    fun atualizar(id: Int, nome: String, endereco: String, descricao: String, foto: Uri?) = executar {
        LojaValidator.validar(nome, endereco, descricao)
        val usuarioId = SessaoUsuario.exigirUsuario()
        val original = requireNotNull(lojas.firstOrNull { it.id == id }) {
            "Loja não encontrada."
        }

        lojas = withContext(Dispatchers.IO) {
            val novoCaminho = foto?.let { ArmazenamentoImagem.salvarCapa(contexto, it) }
            val atualizada = original.copy(
                nome = nome.trim(),
                endereco = endereco.trim(),
                descricao = descricao.trim(),
                fotoArquivo = novoCaminho ?: original.fotoArquivo
            )
            try {
                dao.atualizar(usuarioId, atualizada)
            } catch (e: Exception) {
                ArmazenamentoImagem.apagar(novoCaminho)
                throw e
            }
            if (novoCaminho != null) ArmazenamentoImagem.apagar(original.fotoArquivo)
            dao.listar(usuarioId)
        }
        aviso = "Loja atualizada."
        concluido = true
    }

    fun remover(id: Int) = executar {
        val usuarioId = SessaoUsuario.exigirUsuario()
        val loja = lojas.firstOrNull { it.id == id } ?: return@executar

        lojas = withContext(Dispatchers.IO) {
            dao.remover(usuarioId, id)
            ArmazenamentoImagem.apagar(loja.fotoArquivo)
            dao.listar(usuarioId)
        }
        aviso = "Loja removida."
    }

    fun avisar(texto: String) {
        aviso = texto
    }

    fun consumirConclusao() {
        concluido = false
    }

    fun limparErro() {
        erro = null
    }

    fun limparAviso() {
        aviso = null
    }
}
