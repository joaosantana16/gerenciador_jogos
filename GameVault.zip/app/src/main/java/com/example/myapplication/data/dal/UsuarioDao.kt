package com.example.myapplication.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.local.JogosIniciais
import com.example.myapplication.data.local.LojasIniciais
import com.example.myapplication.data.model.Endereco
import com.example.myapplication.data.model.Usuario

internal class SenhaSalva(val hash: ByteArray, val salt: ByteArray, val usuarioID: Long)

internal class UsuarioDao(context: Context) {
    private val appContext = context.applicationContext

    fun cadastrar(
        nome: String,
        email: String,
        senha: ByteArray,
        salt: ByteArray,
        endereco: Endereco
    ) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("nome", nome)
                put("email", email)
                put("senha", senha)
                put("salt", salt)
                put("cep", endereco.cep)
                put("logradouro", endereco.logradouro)
                put("bairro", endereco.bairro)
                put("cidade", endereco.cidade)
                put("uf", endereco.uf)
            }
            val banco = db.writableDatabase
            banco.beginTransaction()
            try {
                val usuarioId = banco.insertOrThrow("usuarios", null, dados)
                JogosIniciais.inserirPara(banco, usuarioId)
                LojasIniciais.inserirPara(banco, usuarioId)
                banco.setTransactionSuccessful()
            } finally {
                banco.endTransaction()
            }
        }
    }

    fun buscarSenha(email: String): SenhaSalva? {
        return AppDatabase(appContext).use { db ->
            db.readableDatabase.query(
                "usuarios",
                arrayOf("senha", "salt", "id"),
                "email = ?",
                arrayOf(email),
                null, null, null
            ).use { cursor ->
                if (cursor.moveToFirst()) SenhaSalva(
                    cursor.getBlob(0),
                    cursor.getBlob(1),
                    cursor.getLong(2)
                ) else null
            }
        }
    }

    fun buscarPorId(id: Long): Usuario? = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "usuarios",
            arrayOf("id", "nome", "email", "cep", "logradouro", "bairro", "cidade", "uf"),
            "id = ?",
            arrayOf(id.toString()),
            null, null, null
        ).use { cursor ->
            if (cursor.moveToFirst()) Usuario(
                id = cursor.getLong(0),
                nome = cursor.getString(1),
                email = cursor.getString(2),
                endereco = Endereco(
                    cep = cursor.getString(3).orEmpty(),
                    logradouro = cursor.getString(4).orEmpty(),
                    bairro = cursor.getString(5).orEmpty(),
                    cidade = cursor.getString(6).orEmpty(),
                    uf = cursor.getString(7).orEmpty()
                )
            ) else null
        }
    }
}
