package com.example.myapplication.ui.viewmodel

import android.app.Application
import android.database.sqlite.SQLiteConstraintException
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.auth.AuthManager
import com.example.myapplication.auth.SessaoUsuario
import com.example.myapplication.data.dal.UsuarioDao
import com.example.myapplication.data.model.Endereco
import com.example.myapplication.data.remote.ClienteCep
import com.example.myapplication.validation.CadastroValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = UsuarioDao(application)

    var carregando by mutableStateOf(false)
        private set
    var concluido by mutableStateOf(false)
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set

    private fun executar(op: suspend () -> Boolean) {
        if (carregando || concluido) return
        carregando = true
        mensagem = null

        viewModelScope.launch {
            try {
                concluido = withContext(Dispatchers.IO) { op() }
                if (!concluido) mensagem = "E-mail ou senha inválido."
            } catch (e: CancellationException) {
                throw e
            } catch (e: SQLiteConstraintException) {

                mensagem = "Não foi possível cadastrar."
            } catch (e: IllegalArgumentException) {

                mensagem = e.message
            } catch (e: HttpException) {
                mensagem = "Não foi possível consultar o CEP agora. Tente novamente."
            } catch (e: IOException) {
                mensagem = "Sem conexão para consultar o CEP. Verifique a internet."
            } catch (e: Exception) {
                mensagem = "Ocorreu um erro inesperado."
            } finally {
                carregando = false
            }
        }
    }

    fun cadastrar(nome: String, email: String, senha: String, cep: String) = executar {
        val nomeLimpo = nome.trim()
        val emailLimpo = email.trim().lowercase()
        val cepLimpo = cep.filter { it.isDigit() }

        CadastroValidator.validar(nomeLimpo, emailLimpo, senha, cepLimpo)

        val resposta = ClienteCep.api.consultar(cepLimpo)
        require(resposta.erro != true) { "CEP não encontrado." }

        val endereco = Endereco(
            cep = cepLimpo,
            logradouro = resposta.logradouro.orEmpty(),
            bairro = resposta.bairro.orEmpty(),
            cidade = resposta.localidade.orEmpty(),
            uf = resposta.uf.orEmpty()
        )

        val salt = AuthManager.criarSalt()
        val senhaHash = AuthManager.gerarHash(senha, salt)
        try {
            dao.cadastrar(nomeLimpo, emailLimpo, senhaHash, salt, endereco)
            true
        } finally {
            senhaHash.fill(0)
        }
    }

    fun login(email: String, senha: String) = executar {
        require(email.length <= 254 && senha.length in 6..128) {
            "E-mail ou senha inválido."
        }

        val dados = dao.buscarSenha(email.trim().lowercase())

        val hashDoBanco = dados?.hash ?: ByteArray(32)
        val salt = dados?.salt ?: ByteArray(16)

        val senhaConfere = try {
            AuthManager.validarSenha(senha, salt, hashDoBanco)
        } finally {
            hashDoBanco.fill(0)
        }

        if (senhaConfere && dados != null) {
            SessaoUsuario.iniciar(dados.usuarioID)
            true
        } else {
            false
        }
    }

    fun consumirResultado() {
        concluido = false
    }
}
