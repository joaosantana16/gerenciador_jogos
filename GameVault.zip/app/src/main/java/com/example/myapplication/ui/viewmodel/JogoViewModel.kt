package com.example.myapplication.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.auth.SessaoUsuario
import com.example.myapplication.data.dal.JogoDao
import com.example.myapplication.data.local.ArmazenamentoImagem
import com.example.myapplication.data.model.Jogo
import com.example.myapplication.data.model.StatusJogo
import com.example.myapplication.validation.JogoValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class JogoViewModel(application: Application) : AndroidViewModel(application) {
    private val contexto = application
    private val dao = JogoDao(application)

    var jogos by mutableStateOf<List<Jogo>>(emptyList())
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set
    var salvo by mutableStateOf(false)
        private set
    var carregando by mutableStateOf(false)
        private set
    var processando by mutableStateOf(false)
        private set

    var capaEscolhida by mutableStateOf<String?>(null)
        private set
    var carregandoImagem by mutableStateOf(false)
        private set
    private var capaPendente: String? = null
    private var formularioAberto = false
    private var usuarioCarregado: Long? = null

    val totalJogos: Int get() = jogos.size
    val concluidos: Int get() = jogos.count { it.status == StatusJogo.CONCLUIDO }
    val horasTotais: Int get() = jogos.sumOf { it.horas }
    val generoFavorito: String
        get() = jogos.map { it.genero }
            .filter { it.isNotBlank() }
            .groupingBy { it }
            .eachCount()
            .maxByOrNull { it.value }
            ?.key ?: "—"

    val principais: List<Jogo>
        get() = jogos
            .sortedWith(compareByDescending<Jogo> { it.horas }.thenByDescending { it.nota })
            .take(5)

    fun buscarPorId(id: Int): Jogo? = jogos.firstOrNull { it.id == id }

    fun carregar() {
        val usuarioId = SessaoUsuario.usuarioId ?: return
        if (usuarioId != usuarioCarregado) {
            jogos = emptyList()
            usuarioCarregado = usuarioId
        }
        carregando = true

        viewModelScope.launch {
            try {
                jogos = withContext(Dispatchers.IO) { dao.listar(usuarioId) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                mensagem = "Não foi possível carregar os jogos."
            } finally {
                carregando = false
            }
        }
    }

    private fun executar(op: suspend () -> Unit) {
        if (processando) return
        processando = true
        mensagem = null

        viewModelScope.launch {
            try {
                op()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                mensagem = e.message
            } catch (e: Exception) {
                mensagem = "Ocorreu um erro inesperado."
            } finally {
                processando = false
            }
        }
    }

    fun iniciarFormulario(jogoId: Int?) {
        mensagem = null
        formularioAberto = true
        capaPendente = null
        capaEscolhida = jogoId?.let { buscarPorId(it) }?.capaArquivo
    }

    fun escolherCapa(uri: Uri) {
        if (carregandoImagem) return
        carregandoImagem = true
        mensagem = null

        viewModelScope.launch {
            try {
                val caminho = withContext(Dispatchers.IO) {
                    ArmazenamentoImagem.salvarCapa(contexto, uri)
                }
                if (!formularioAberto) {
                    ArmazenamentoImagem.apagar(caminho)
                } else {
                    ArmazenamentoImagem.apagar(capaPendente)
                    capaPendente = caminho
                    capaEscolhida = caminho
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                mensagem = e.message
            } catch (e: Exception) {
                mensagem = "Não foi possível carregar a imagem."
            } finally {
                carregandoImagem = false
            }
        }
    }

    fun removerCapaEscolhida() {
        ArmazenamentoImagem.apagar(capaPendente)
        capaPendente = null
        capaEscolhida = null
    }

    fun cancelarFormulario() {
        formularioAberto = false
        ArmazenamentoImagem.apagar(capaPendente)
        capaPendente = null
        capaEscolhida = null
    }

    fun adicionar(
        nome: String,
        plataforma: String,
        horas: String,
        genero: String,
        status: StatusJogo,
        nota: Int
    ) = executar {
        JogoValidator.validar(nome, horas, genero)
        val usuarioId = SessaoUsuario.exigirUsuario()

        val novo = Jogo(
            id = 0,
            titulo = nome.trim(),
            plataforma = plataforma,
            horas = JogoValidator.extrairHoras(horas),
            status = status,
            genero = genero.trim(),
            nota = nota,
            capaArquivo = capaEscolhida
        )

        jogos = withContext(Dispatchers.IO) {
            dao.inserir(usuarioId, novo)
            dao.listar(usuarioId)
        }
        capaPendente = null
        salvo = true
    }

    fun atualizar(
        id: Int,
        nome: String,
        plataforma: String,
        horas: String,
        genero: String,
        status: StatusJogo,
        nota: Int
    ) = executar {
        JogoValidator.validar(nome, horas, genero)
        val usuarioId = SessaoUsuario.exigirUsuario()
        val original = requireNotNull(buscarPorId(id)) { "Jogo não encontrado." }
        val novaCapa = capaEscolhida

        val atualizado = original.copy(
            titulo = nome.trim(),
            plataforma = plataforma,
            horas = JogoValidator.extrairHoras(horas),
            status = status,
            genero = genero.trim(),
            nota = nota,
            capaArquivo = novaCapa
        )

        jogos = withContext(Dispatchers.IO) {
            dao.atualizar(usuarioId, atualizado)
            if (original.capaArquivo != null && original.capaArquivo != novaCapa) {
                ArmazenamentoImagem.apagar(original.capaArquivo)
            }
            dao.listar(usuarioId)
        }
        capaPendente = null
        salvo = true
    }

    fun remover(id: Int) = executar {
        val usuarioId = SessaoUsuario.exigirUsuario()
        val jogo = buscarPorId(id) ?: return@executar

        jogos = withContext(Dispatchers.IO) {
            dao.remover(usuarioId, id)
            ArmazenamentoImagem.apagar(jogo.capaArquivo)
            dao.listar(usuarioId)
        }
    }

    fun consumirSalvo() {
        salvo = false
    }

    fun limparMensagem() {
        mensagem = null
    }
}
