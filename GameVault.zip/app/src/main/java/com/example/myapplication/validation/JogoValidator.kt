package com.example.myapplication.validation

object JogoValidator {

    fun validar(nome: String, horasTexto: String, genero: String) {
        require(nome.trim().length in 2..100) {
            "Informe o nome do jogo (de 2 a 100 caracteres)."
        }
        require(genero.trim().length <= 50) {
            "O gênero pode ter no máximo 50 caracteres."
        }

        if (horasTexto.isNotBlank()) {
            val digitos = horasTexto.filter { it.isDigit() }
            require(digitos.isNotEmpty()) { "Informe as horas jogadas usando números." }
            require(digitos.length <= 5) { "Informe no máximo 99999 horas." }
        }
    }

    fun extrairHoras(horasTexto: String): Int =
        horasTexto.filter { it.isDigit() }.toIntOrNull() ?: 0
}
