package com.example.myapplication.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.model.StatusJogo
import com.example.myapplication.ui.theme.CinzaConcluido
import com.example.myapplication.ui.theme.RoxoProximo
import com.example.myapplication.ui.theme.VerdeJogando

@Composable
fun SeloDeStatus(status: StatusJogo) {

    val cor = when (status) {
        StatusJogo.JOGANDO -> VerdeJogando
        StatusJogo.PROXIMO -> RoxoProximo
        StatusJogo.CONCLUIDO -> CinzaConcluido
    }

    Surface(
        shape = RoundedCornerShape(50),
        color = cor
    ) {
        Text(
            text = status.rotulo,
            color = if (status == StatusJogo.JOGANDO) Color.Black else Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
