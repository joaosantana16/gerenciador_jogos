package com.example.myapplication.validation

import android.util.Patterns

object CadastroValidator {

    fun validar(nome: String, email: String, senha: String, cep: String) {
        require(email.length <= 254 && Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            "Informe um e-mail válido."
        }
        require(nome.length in 3..100) {
            "Informe um nome entre 3 e 100 caracteres."
        }
        require(senha.length in 6..128 && senha.isNotBlank()) {
            "Use uma senha entre 6 e 128 caracteres."
        }
        require(cep.length == 8 && cep.all { it.isDigit() }) {
            "Informe um CEP com 8 números."
        }
    }
}
