package com.example.myapplication.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import com.example.myapplication.R
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.TextGray

@Composable
fun FotoLoja(
    fotoArquivo: String?,
    descricao: String,
    modifier: Modifier = Modifier
) {
    if (fotoArquivo != null) {
        ImagemCapa(
            capa = null,
            capaArquivo = fotoArquivo,
            descricao = descricao,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier.background(CardDark),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_loja),
                contentDescription = descricao,
                tint = TextGray
            )
        }
    }
}
