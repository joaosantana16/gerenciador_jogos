package com.example.myapplication.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.auth.SessaoUsuario
import com.example.myapplication.data.dal.AnotacaoDao
import com.example.myapplication.data.model.Anotacao
import com.example.myapplication.validation.AnotacaoValidator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AnotacaoViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AnotacaoDao(application)
    private var jogoAtual: Int? = null

    var anotacoes by mutableStateOf<List<Anotacao>>(emptyList())
        private set
    var mensagem by mutableStateOf<String?>(null)
        private set
    var processando by mutableStateOf(false)
        private set
    var concluido by mutableStateOf(false)
        private set

    fun carregar(jogoId: Int) {
        if (SessaoUsuario.usuarioId == null) return
        if (jogoId != jogoAtual) {
            anotacoes = emptyList()
            jogoAtual = jogoId
        }

        viewModelScope.launch {
            try {
                anotacoes = withContext(Dispatchers.IO) { dao.listar(jogoId) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                mensagem = "Não foi possível carregar as anotações."
            }
        }
    }

    private fun executar(op: suspend () -> Unit) {
        if (processando) return
        processando = true
        mensagem = null

        viewModelScope.launch {
            try {
                op()
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                mensagem = e.message
            } catch (e: Exception) {
                mensagem = "Ocorreu um erro inesperado."
            } finally {
                processando = false
            }
        }
    }

    fun adicionar(jogoId: Int, texto: String) = executar {
        AnotacaoValidator.validar(texto)
        SessaoUsuario.exigirUsuario()

        anotacoes = withContext(Dispatchers.IO) {
            dao.inserir(jogoId, texto.trim())
            dao.listar(jogoId)
        }
        concluido = true
    }

    fun atualizar(id: Int, jogoId: Int, texto: String) = executar {
        AnotacaoValidator.validar(texto)
        SessaoUsuario.exigirUsuario()

        anotacoes = withContext(Dispatchers.IO) {
            dao.atualizar(id, jogoId, texto.trim())
            dao.listar(jogoId)
        }
        concluido = true
    }

    fun remover(id: Int, jogoId: Int) = executar {
        SessaoUsuario.exigirUsuario()

        anotacoes = withContext(Dispatchers.IO) {
            dao.remover(id, jogoId)
            dao.listar(jogoId)
        }
    }

    fun consumirConclusao() {
        concluido = false
    }

    fun limparMensagem() {
        mensagem = null
    }
}
