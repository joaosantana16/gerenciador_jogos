package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF121212)
val CardDark = Color(0xFF1E1E1E)
val BottomBarDark = Color(0xFF1A1A1A)
val PurpleAccent = Color(0xFF6C63FF)
val GreenAccent = Color(0xFFB4F461)
val TextGray = Color(0xFFAAAAAA)
val IconeInativo = Color(0xFF777777)

val VerdeJogando = Color(0xFFB6E33D)
val RoxoProximo = Color(0xFF7B5CFA)
val CinzaConcluido = Color(0xFF3A3A3A)

val BotaoEditarFundo = Color(0xFF2A2A2A)
val BotaoRemoverFundo = Color(0xFF3A1414)
val VermelhoRemover = Color(0xFFFF5252)
