package com.example.myapplication.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.myapplication.R
import com.example.myapplication.navigation.AdicionarJogo
import com.example.myapplication.navigation.Biblioteca
import com.example.myapplication.navigation.DetalhesJogo
import com.example.myapplication.navigation.EditarJogo
import com.example.myapplication.navigation.Inicio
import com.example.myapplication.navigation.Lojas
import com.example.myapplication.navigation.Perfil
import com.example.myapplication.navigation.opcoesDeAba
import com.example.myapplication.ui.theme.BottomBarDark
import com.example.myapplication.ui.theme.GreenAccent
import com.example.myapplication.ui.theme.IconeInativo

@Composable
fun BarraInferior(navController: NavHostController) {

    val entradaAtual by navController.currentBackStackEntryAsState()
    val destino = entradaAtual?.destination

    val noInicio = destino?.hasRoute<Inicio>() == true
    val naBiblioteca = destino?.hasRoute<Biblioteca>() == true ||
            destino?.hasRoute<DetalhesJogo>() == true ||
            destino?.hasRoute<EditarJogo>() == true
    val noAdicionar = destino?.hasRoute<AdicionarJogo>() == true
    val nasLojas = destino?.hasRoute<Lojas>() == true
    val noPerfil = destino?.hasRoute<Perfil>() == true

    BottomAppBar(containerColor = BottomBarDark) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ItemBarra(R.drawable.ic_home, "Início", noInicio) {
                navController.navigate(Inicio, opcoesDeAba)
            }

            ItemBarra(R.drawable.ic_jogos, "Biblioteca", naBiblioteca) {
                navController.navigate(Biblioteca, opcoesDeAba)
            }

            ItemBarra(R.drawable.ic_adicionar, "Adicionar jogo", noAdicionar) {
                navController.navigate(AdicionarJogo, opcoesDeAba)
            }

            ItemBarra(R.drawable.ic_loja, "Lojas", nasLojas) {
                navController.navigate(Lojas, opcoesDeAba)
            }

            ItemBarra(R.drawable.ic_perfil, "Perfil", noPerfil) {
                navController.navigate(Perfil, opcoesDeAba)
            }
        }
    }
}

@Composable
private fun ItemBarra(
    icone: Int,
    descricao: String,
    selecionado: Boolean,
    aoClicar: () -> Unit
) {
    IconButton(onClick = aoClicar) {
        Icon(
            painter = painterResource(icone),
            contentDescription = descricao,
            tint = if (selecionado) GreenAccent else IconeInativo,
            modifier = Modifier.size(24.dp)
        )
    }
}
