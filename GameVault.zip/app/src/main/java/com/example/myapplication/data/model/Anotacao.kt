package com.example.myapplication.data.model

data class Anotacao(
    val id: Int,
    val jogoId: Int,
    val texto: String
)
