package com.example.myapplication.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.model.Jogo
import com.example.myapplication.data.model.StatusJogo

internal class JogoDao(context: Context) {
    private val appContext = context.applicationContext

    fun listar(usuarioId: Long): List<Jogo> = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "jogos",
            arrayOf(
                "id", "titulo", "plataforma", "horas", "status",
                "genero", "desenvolvedora", "nota", "capa_recurso", "capa_arquivo"
            ),
            "usuario_id = ?",
            arrayOf(usuarioId.toString()),
            null, null,
            "id"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(
                        Jogo(
                            id = cursor.getInt(0),
                            titulo = cursor.getString(1),
                            plataforma = cursor.getString(2),
                            horas = cursor.getInt(3),
                            status = StatusJogo.valueOf(cursor.getString(4)),
                            genero = cursor.getString(5),
                            desenvolvedora = cursor.getString(6),
                            nota = cursor.getInt(7),
                            capa = idDoRecurso(cursor.getString(8)),
                            capaArquivo = cursor.getString(9)
                        )
                    )
                }
            }
        }
    }

    fun inserir(usuarioId: Long, jogo: Jogo) {
        AppDatabase(appContext).use { db ->
            db.writableDatabase.insertOrThrow("jogos", null, valores(usuarioId, jogo))
        }
    }

    fun atualizar(usuarioId: Long, jogo: Jogo) {
        AppDatabase(appContext).use { db ->
            val alterados = db.writableDatabase.update(
                "jogos",
                valores(usuarioId, jogo),
                "id = ? AND usuario_id = ?",
                arrayOf(jogo.id.toString(), usuarioId.toString())
            )
            require(alterados == 1) { "Não foi possível alterar o jogo." }
        }
    }

    fun remover(usuarioId: Long, id: Int) {
        AppDatabase(appContext).use { db ->
            val removidos = db.writableDatabase.delete(
                "jogos",
                "id = ? AND usuario_id = ?",
                arrayOf(id.toString(), usuarioId.toString())
            )
            require(removidos == 1) { "Não foi possível remover o jogo." }
        }
    }

    private fun valores(usuarioId: Long, jogo: Jogo) = ContentValues().apply {
        put("usuario_id", usuarioId)
        put("titulo", jogo.titulo)
        put("plataforma", jogo.plataforma)
        put("horas", jogo.horas)
        put("status", jogo.status.name)
        put("genero", jogo.genero)
        put("desenvolvedora", jogo.desenvolvedora)
        put("nota", jogo.nota)
        put("capa_recurso", nomeDoRecurso(jogo.capa))
        put("capa_arquivo", jogo.capaArquivo)
    }

    private fun nomeDoRecurso(id: Int?): String? =
        id?.let { runCatching { appContext.resources.getResourceEntryName(it) }.getOrNull() }

    private fun idDoRecurso(nome: String?): Int? =
        nome?.let {
            appContext.resources.getIdentifier(it, "drawable", appContext.packageName)
                .takeIf { id -> id != 0 }
        }
}
