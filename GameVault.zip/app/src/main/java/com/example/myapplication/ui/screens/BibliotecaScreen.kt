package com.example.myapplication.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.model.Jogo
import com.example.myapplication.ui.components.ImagemCapa
import com.example.myapplication.ui.components.SeloDeStatus
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.TextGray
import com.example.myapplication.ui.viewmodel.JogoViewModel

@Composable
fun BibliotecaScreen(
    jogoViewModel: JogoViewModel,
    abrirDetalhes: (Int) -> Unit
) {

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "MINHA BIBLIOTECA",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (jogoViewModel.jogos.isEmpty() && !jogoViewModel.carregando) {
            item {
                Text("Nenhum jogo cadastrado ainda. Toque em + para adicionar.", color = TextGray)
            }
        }

        items(items = jogoViewModel.jogos, key = { it.id }) { jogo ->
            CardJogo(jogo = jogo, aoClicar = { abrirDetalhes(jogo.id) })
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CardJogo(jogo: Jogo, aoClicar: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { aoClicar() },
        colors = CardDefaults.cardColors(containerColor = CardDark),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ImagemCapa(
                capa = jogo.capa,
                capaArquivo = jogo.capaArquivo,
                descricao = jogo.titulo,
                modifier = Modifier.size(width = 60.dp, height = 80.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                SeloDeStatus(jogo.status)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = jogo.titulo.uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${jogo.plataforma} | ${jogo.horas} h",
                    color = TextGray,
                    fontSize = 14.sp
                )
            }
        }
    }
}
