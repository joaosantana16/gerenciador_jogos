package com.example.myapplication.ui.components

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.PurpleAccent
import com.example.myapplication.ui.theme.TextGray

@Composable
fun coresDoCampo(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = CardDark,
    unfocusedContainerColor = CardDark,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = PurpleAccent,
    unfocusedBorderColor = TextGray.copy(alpha = 0.3f),
    focusedLabelColor = PurpleAccent,
    unfocusedLabelColor = TextGray,
    cursorColor = PurpleAccent
)
