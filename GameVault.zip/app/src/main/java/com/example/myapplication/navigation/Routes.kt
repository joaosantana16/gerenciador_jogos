package com.example.myapplication.navigation

import kotlinx.serialization.Serializable

@Serializable
data object Login

@Serializable
data object Cadastro

@Serializable
data object Inicio

@Serializable
data object Biblioteca

@Serializable
data class DetalhesJogo(val id: Int)

@Serializable
data object AdicionarJogo

@Serializable
data class EditarJogo(val id: Int)

@Serializable
data object Lojas

@Serializable
data object Perfil
