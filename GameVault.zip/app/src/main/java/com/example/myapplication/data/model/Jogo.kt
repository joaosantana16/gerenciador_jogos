package com.example.myapplication.data.model

enum class StatusJogo(val rotulo: String) {
    JOGANDO("JOGANDO"),
    PROXIMO("PRÓXIMO"),
    CONCLUIDO("CONCLUÍDO")
}

data class Jogo(
    val id: Int,
    val titulo: String,
    val plataforma: String,
    val horas: Int,
    val status: StatusJogo,
    val genero: String = "",
    val desenvolvedora: String = "",
    val nota: Int = 0,
    val capa: Int? = null,
    val capaArquivo: String? = null
)
