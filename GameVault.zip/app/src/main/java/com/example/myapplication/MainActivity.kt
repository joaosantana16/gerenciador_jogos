package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.navigation.AppNavigation
import com.example.myapplication.navigation.Biblioteca
import com.example.myapplication.navigation.Cadastro
import com.example.myapplication.navigation.Inicio
import com.example.myapplication.navigation.Login
import com.example.myapplication.navigation.Lojas
import com.example.myapplication.navigation.Perfil
import com.example.myapplication.navigation.sair
import com.example.myapplication.ui.components.BarraInferior
import com.example.myapplication.ui.components.TopoGameVault
import com.example.myapplication.ui.theme.BgDark
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.example.myapplication.ui.viewmodel.JogoViewModel
import com.example.myapplication.ui.viewmodel.LojaViewModel
import androidx.compose.runtime.LaunchedEffect
import com.example.myapplication.auth.SessaoUsuario

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                val navController = rememberNavController()

                val jogoViewModel: JogoViewModel = viewModel()
                val lojaViewModel: LojaViewModel = viewModel()
                LaunchedEffect(SessaoUsuario.usuarioId) { jogoViewModel.carregar() }

                val entradaAtual by navController.currentBackStackEntryAsState()
                val destino = entradaAtual?.destination

                val telaPublica = destino == null ||
                        destino.hasRoute<Login>() ||
                        destino.hasRoute<Cadastro>()

                val mostrarTopo = destino?.hasRoute<Inicio>() == true ||
                        destino?.hasRoute<Biblioteca>() == true ||
                        destino?.hasRoute<Lojas>() == true ||
                        destino?.hasRoute<Perfil>() == true

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = BgDark,

                    contentColor = Color.White,
                    topBar = {
                        if (mostrarTopo) {
                            TopoGameVault(onSair = { navController.sair() })
                        }
                    },
                    bottomBar = {
                        if (!telaPublica) {
                            BarraInferior(navController = navController)
                        }
                    }
                ) { innerPadding ->
                    AppNavigation(
                        navController = navController,
                        jogoViewModel = jogoViewModel,
                        lojaViewModel = lojaViewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}
