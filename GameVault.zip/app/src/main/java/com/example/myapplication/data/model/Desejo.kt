package com.example.myapplication.data.model

val PRIORIDADES = listOf("Baixa", "Média", "Alta")

data class Desejo(
    val id: Int,
    val titulo: String,
    val plataforma: String,
    val prioridade: Int
) {
    val rotuloPrioridade: String
        get() = PRIORIDADES.getOrElse(prioridade - 1) { PRIORIDADES[1] }
}
