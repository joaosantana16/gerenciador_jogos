package com.example.myapplication.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.model.Anotacao

internal class AnotacaoDao(context: Context) {
    private val appContext = context.applicationContext

    fun listar(jogoId: Int): List<Anotacao> = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "anotacoes",
            arrayOf("id", "jogo_id", "texto"),
            "jogo_id = ?",
            arrayOf(jogoId.toString()),
            null, null,
            "id DESC"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(
                        Anotacao(
                            id = cursor.getInt(0),
                            jogoId = cursor.getInt(1),
                            texto = cursor.getString(2)
                        )
                    )
                }
            }
        }
    }

    fun inserir(jogoId: Int, texto: String) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply {
                put("jogo_id", jogoId)
                put("texto", texto)
            }
            db.writableDatabase.insertOrThrow("anotacoes", null, dados)
        }
    }

    fun atualizar(id: Int, jogoId: Int, texto: String) {
        AppDatabase(appContext).use { db ->
            val dados = ContentValues().apply { put("texto", texto) }
            val alterados = db.writableDatabase.update(
                "anotacoes",
                dados,
                "id = ? AND jogo_id = ?",
                arrayOf(id.toString(), jogoId.toString())
            )
            require(alterados == 1) { "Não foi possível alterar a anotação." }
        }
    }

    fun remover(id: Int, jogoId: Int) {
        AppDatabase(appContext).use { db ->
            val removidos = db.writableDatabase.delete(
                "anotacoes",
                "id = ? AND jogo_id = ?",
                arrayOf(id.toString(), jogoId.toString())
            )
            require(removidos == 1) { "Não foi possível remover a anotação." }
        }
    }
}
