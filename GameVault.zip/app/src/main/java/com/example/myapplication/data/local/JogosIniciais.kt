package com.example.myapplication.data.local

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import com.example.myapplication.data.model.StatusJogo

internal object JogosIniciais {
    private class Modelo(
        val titulo: String,
        val plataforma: String,
        val horas: Int,
        val status: StatusJogo,
        val genero: String,
        val desenvolvedora: String,
        val nota: Int,
        val capaRecurso: String
    )

    private val modelos = listOf(
        Modelo("Alan Wake 2", "PS5", 8, StatusJogo.JOGANDO, "Survival Horror", "Remedy Entertainment", 0, "capa_alan_wake_2"),
        Modelo("GTA VI", "PS5", 0, StatusJogo.PROXIMO, "Ação e Aventura", "Rockstar Games", 0, "capa_gta_vi"),
        Modelo("Control", "PS5", 124, StatusJogo.CONCLUIDO, "Ação e Aventura", "Remedy Entertainment", 5, "capa_control")
    )

    fun inserirPara(db: SQLiteDatabase, usuarioId: Long) {
        for (modelo in modelos) {
            val valores = ContentValues().apply {
                put("usuario_id", usuarioId)
                put("titulo", modelo.titulo)
                put("plataforma", modelo.plataforma)
                put("horas", modelo.horas)
                put("status", modelo.status.name)
                put("genero", modelo.genero)
                put("desenvolvedora", modelo.desenvolvedora)
                put("nota", modelo.nota)
                put("capa_recurso", modelo.capaRecurso)
            }
            db.insertOrThrow("jogos", null, valores)
        }
    }

    fun inserirParaTodos(db: SQLiteDatabase) {
        val ids = mutableListOf<Long>()
        db.rawQuery("SELECT id FROM usuarios", null).use { cursor ->
            while (cursor.moveToNext()) ids.add(cursor.getLong(0))
        }
        ids.forEach { inserirPara(db, it) }
    }
}
