package com.example.myapplication.data.model

data class Loja(
    val id: Int,
    val nome: String,
    val endereco: String,
    val descricao: String = "",
    val fotoArquivo: String? = null
)
