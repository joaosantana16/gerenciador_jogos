package com.example.myapplication.data.model

data class Endereco(
    val cep: String = "",
    val logradouro: String = "",
    val bairro: String = "",
    val cidade: String = "",
    val uf: String = ""
) {
    val cepFormatado: String
        get() = if (cep.length == 8) "${cep.substring(0, 5)}-${cep.substring(5)}" else cep

    val ruaEBairro: String
        get() = listOf(logradouro, bairro).filter { it.isNotBlank() }.joinToString(" - ")

    val cidadeEUf: String
        get() = listOf(cidade, uf).filter { it.isNotBlank() }.joinToString(" - ")
}
