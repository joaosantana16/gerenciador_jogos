package com.example.myapplication.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

data class RespostaCep(
    val cep: String? = null,
    val logradouro: String? = null,
    val complemento: String? = null,
    val bairro: String? = null,
    val localidade: String? = null,
    val uf: String? = null,
    val erro: Boolean? = null
)

interface CepApi {
    @GET("ws/{cep}/json/")
    suspend fun consultar(@Path("cep") cep: String): RespostaCep
}

object ClienteCep {
    val api: CepApi by lazy {
        val cliente = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()

        Retrofit.Builder()
            .baseUrl("https://viacep.com.br/")
            .client(cliente)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CepApi::class.java)
    }
}
