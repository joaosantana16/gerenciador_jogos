package com.example.myapplication.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.model.Loja

internal class LojaDao(context: Context) {
    private val appContext = context.applicationContext

    fun listar(usuarioId: Long): List<Loja> = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "lojas",
            arrayOf("id", "nome", "endereco", "descricao", "foto_arquivo"),
            "usuario_id = ?",
            arrayOf(usuarioId.toString()),
            null, null,
            "nome COLLATE NOCASE, id"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(
                        Loja(
                            id = cursor.getInt(0),
                            nome = cursor.getString(1),
                            endereco = cursor.getString(2),
                            descricao = cursor.getString(3),
                            fotoArquivo = cursor.getString(4)
                        )
                    )
                }
            }
        }
    }

    fun inserir(usuarioId: Long, loja: Loja) {
        AppDatabase(appContext).use { db ->
            db.writableDatabase.insertOrThrow("lojas", null, valores(usuarioId, loja))
        }
    }

    fun atualizar(usuarioId: Long, loja: Loja) {
        AppDatabase(appContext).use { db ->
            val alterados = db.writableDatabase.update(
                "lojas",
                valores(usuarioId, loja),
                "id = ? AND usuario_id = ?",
                arrayOf(loja.id.toString(), usuarioId.toString())
            )
            require(alterados == 1) { "Não foi possível alterar a loja." }
        }
    }

    fun remover(usuarioId: Long, id: Int) {
        AppDatabase(appContext).use { db ->
            val removidos = db.writableDatabase.delete(
                "lojas",
                "id = ? AND usuario_id = ?",
                arrayOf(id.toString(), usuarioId.toString())
            )
            require(removidos == 1) { "Não foi possível remover a loja." }
        }
    }

    private fun valores(usuarioId: Long, loja: Loja) = ContentValues().apply {
        put("usuario_id", usuarioId)
        put("nome", loja.nome)
        put("endereco", loja.endereco)
        put("descricao", loja.descricao)
        put("foto_arquivo", loja.fotoArquivo)
    }
}
