package com.example.myapplication.data.dal

import android.content.ContentValues
import android.content.Context
import com.example.myapplication.data.local.AppDatabase
import com.example.myapplication.data.model.Desejo

internal class DesejoDao(context: Context) {
    private val appContext = context.applicationContext

    fun listar(usuarioId: Long): List<Desejo> = AppDatabase(appContext).use { db ->
        db.readableDatabase.query(
            "desejos",
            arrayOf("id", "titulo", "plataforma", "prioridade"),
            "usuario_id = ?",
            arrayOf(usuarioId.toString()),
            null, null,
            "prioridade DESC, titulo COLLATE NOCASE"
        ).use { cursor ->
            buildList {
                while (cursor.moveToNext()) {
                    add(
                        Desejo(
                            id = cursor.getInt(0),
                            titulo = cursor.getString(1),
                            plataforma = cursor.getString(2),
                            prioridade = cursor.getInt(3)
                        )
                    )
                }
            }
        }
    }

    fun inserir(usuarioId: Long, desejo: Desejo) {
        AppDatabase(appContext).use { db ->
            db.writableDatabase.insertOrThrow("desejos", null, valores(usuarioId, desejo))
        }
    }

    fun atualizar(usuarioId: Long, desejo: Desejo) {
        AppDatabase(appContext).use { db ->
            val alterados = db.writableDatabase.update(
                "desejos",
                valores(usuarioId, desejo),
                "id = ? AND usuario_id = ?",
                arrayOf(desejo.id.toString(), usuarioId.toString())
            )
            require(alterados == 1) { "Não foi possível alterar o desejo." }
        }
    }

    fun remover(usuarioId: Long, id: Int) {
        AppDatabase(appContext).use { db ->
            val removidos = db.writableDatabase.delete(
                "desejos",
                "id = ? AND usuario_id = ?",
                arrayOf(id.toString(), usuarioId.toString())
            )
            require(removidos == 1) { "Não foi possível remover o desejo." }
        }
    }

    private fun valores(usuarioId: Long, desejo: Desejo) = ContentValues().apply {
        put("usuario_id", usuarioId)
        put("titulo", desejo.titulo)
        put("plataforma", desejo.plataforma)
        put("prioridade", desejo.prioridade)
    }
}
