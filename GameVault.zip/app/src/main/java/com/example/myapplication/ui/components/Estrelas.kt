package com.example.myapplication.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.myapplication.R
import com.example.myapplication.ui.theme.GreenAccent
import com.example.myapplication.ui.theme.TextGray

@Composable
fun Estrelas(
    nota: Int,
    modifier: Modifier = Modifier,
    onNotaChange: ((Int) -> Unit)? = null
) {
    Row(modifier = modifier) {
        for (i in 1..5) {
            val clique = if (onNotaChange != null) {
                Modifier.clickable { onNotaChange(i) }
            } else {
                Modifier
            }

            Icon(
                painter = painterResource(id = R.drawable.ic_estrela),
                contentDescription = "Nota $i",
                tint = if (i <= nota) GreenAccent else TextGray,
                modifier = Modifier.size(28.dp).then(clique)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
    }
}
