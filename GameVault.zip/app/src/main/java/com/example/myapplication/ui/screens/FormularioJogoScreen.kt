package com.example.myapplication.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.model.StatusJogo
import com.example.myapplication.ui.components.Estrelas
import com.example.myapplication.ui.components.ImagemCapa
import com.example.myapplication.ui.components.PlatformField
import com.example.myapplication.ui.components.coresDoCampo
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.PurpleAccent
import com.example.myapplication.ui.theme.TextGray
import com.example.myapplication.ui.viewmodel.JogoViewModel

@Composable
fun FormularioJogoScreen(
    jogoViewModel: JogoViewModel,
    jogoId: Int?,
    aoSalvar: () -> Unit
) {
    val editando = jogoId != null

    val jogoExistente = jogoId?.let { jogoViewModel.buscarPorId(it) }

    var nome by remember { mutableStateOf(jogoExistente?.titulo ?: "") }
    var plataforma by remember { mutableStateOf(jogoExistente?.plataforma ?: "PC") }
    var horas by remember { mutableStateOf(jogoExistente?.horas?.toString() ?: "") }
    var genero by remember { mutableStateOf(jogoExistente?.genero ?: "") }
    var status by remember { mutableStateOf(jogoExistente?.status ?: StatusJogo.PROXIMO) }
    var nota by remember { mutableIntStateOf(jogoExistente?.nota ?: 0) }

    val seletorDeImagem = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) jogoViewModel.escolherCapa(uri)
    }

    LaunchedEffect(jogoId) { jogoViewModel.iniciarFormulario(jogoId) }

    DisposableEffect(Unit) {
        onDispose { jogoViewModel.cancelarFormulario() }
    }

    LaunchedEffect(jogoViewModel.salvo) {
        if (jogoViewModel.salvo) {
            jogoViewModel.consumirSalvo()
            aoSalvar()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (editando) "EDITAR JOGO" else "ADICIONAR JOGO",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        FormLabel("Capa do jogo")
        Spacer(modifier = Modifier.height(8.dp))
        SeletorDeCapa(
            capaArquivo = jogoViewModel.capaEscolhida,
            capaDoApp = jogoExistente?.capa,
            carregando = jogoViewModel.carregandoImagem,
            aoEscolher = {
                seletorDeImagem.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            aoRemover = { jogoViewModel.removerCapaEscolhida() }
        )

        Spacer(modifier = Modifier.height(20.dp))

        FormLabel("Nome do Jogo")
        Spacer(modifier = Modifier.height(6.dp))
        FormTextField(
            value = nome,
            onValueChange = { if (it.length <= 100) nome = it },
            placeholder = "Ex: Dead Space"
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                FormLabel("Plataforma")
                Spacer(modifier = Modifier.height(6.dp))
                PlatformField(selected = plataforma, onSelected = { plataforma = it })
            }

            Column(modifier = Modifier.weight(1f)) {
                FormLabel("Horas Jogadas")
                Spacer(modifier = Modifier.height(6.dp))
                FormTextField(
                    value = horas,
                    onValueChange = { if (it.length <= 10) horas = it },
                    placeholder = "Ex: 12h"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        FormLabel("Gênero")
        Spacer(modifier = Modifier.height(6.dp))
        FormTextField(
            value = genero,
            onValueChange = { if (it.length <= 50) genero = it },
            placeholder = "Ex: Suspense"
        )

        Spacer(modifier = Modifier.height(20.dp))

        FormLabel("Status")
        Spacer(modifier = Modifier.height(8.dp))
        StatusRow(selected = status, onSelect = { status = it })

        Spacer(modifier = Modifier.height(20.dp))

        FormLabel("Sua nota:")
        Spacer(modifier = Modifier.height(8.dp))
        Estrelas(nota = nota, onNotaChange = { nota = it })

        jogoViewModel.mensagem?.let {
            Spacer(modifier = Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = {

                if (jogoId != null) {
                    jogoViewModel.atualizar(jogoId, nome, plataforma, horas, genero, status, nota)
                } else {
                    jogoViewModel.adicionar(nome, plataforma, horas, genero, status, nota)
                }
            },

            enabled = !jogoViewModel.carregandoImagem && !jogoViewModel.processando,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White)
        ) {
            Text(
                text = if (editando) "Salvar alterações" else "Salvar Jogo",
                color = Color.Black,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun SeletorDeCapa(
    capaArquivo: String?,
    capaDoApp: Int?,
    carregando: Boolean,
    aoEscolher: () -> Unit,
    aoRemover: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {

        ImagemCapa(
            capa = capaDoApp,
            capaArquivo = capaArquivo,
            descricao = "Capa do jogo",
            modifier = Modifier
                .size(width = 90.dp, height = 120.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, TextGray.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .clickable { aoEscolher() }
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column {
            Button(
                onClick = aoEscolher,
                enabled = !carregando,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PurpleAccent,
                    contentColor = Color.White
                )
            ) {
                Text(if (capaArquivo == null && capaDoApp == null) "Escolher imagem" else "Trocar imagem")
            }

            if (capaArquivo != null) {
                TextButton(onClick = aoRemover, enabled = !carregando) {
                    Text("Remover imagem")
                }
            }

            if (carregando) {
                Text("Carregando imagem...", color = TextGray, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FormLabel(text: String) {
    Text(text = text, color = TextGray, fontSize = 13.sp)
}

@Composable
private fun FormTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(text = placeholder, color = TextGray.copy(alpha = 0.6f)) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = coresDoCampo()
    )
}

@Composable
private fun StatusRow(
    selected: StatusJogo,
    onSelect: (StatusJogo) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusJogo.entries.forEach { opcao ->
            val selecionado = opcao == selected

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (selecionado) PurpleAccent else Color.Transparent)
                    .border(
                        width = 1.dp,
                        color = if (selecionado) PurpleAccent else TextGray.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .clickable { onSelect(opcao) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = opcao.rotulo,
                    color = if (selecionado) Color.White else TextGray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
