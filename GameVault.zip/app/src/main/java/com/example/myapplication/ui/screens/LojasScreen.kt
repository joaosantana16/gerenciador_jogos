package com.example.myapplication.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.model.Loja
import com.example.myapplication.ui.components.FotoLoja
import com.example.myapplication.ui.components.coresDoCampo
import com.example.myapplication.ui.theme.BgDark
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.PurpleAccent
import com.example.myapplication.ui.theme.TextGray
import com.example.myapplication.ui.theme.VermelhoRemover
import com.example.myapplication.ui.viewmodel.LojaViewModel

@Composable
fun LojasScreen(lojaViewModel: LojaViewModel) {
    val contexto = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var mostrarDialogo by remember { mutableStateOf(false) }
    var lojaEditando by remember { mutableStateOf<Loja?>(null) }
    var lojaRemovendo by remember { mutableStateOf<Loja?>(null) }

    LaunchedEffect(Unit) { lojaViewModel.carregar() }

    LaunchedEffect(lojaViewModel.aviso) {
        val texto = lojaViewModel.aviso
        if (texto != null) {
            snackbarHostState.showSnackbar(texto)
            lojaViewModel.limparAviso()
        }
    }

    Scaffold(
        containerColor = BgDark,
        contentColor = Color.White,
        contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { espaco ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(espaco)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LOJAS DE JOGOS",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Button(
                        onClick = {
                            lojaViewModel.limparErro()
                            lojaEditando = null
                            mostrarDialogo = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PurpleAccent,
                            contentColor = Color.White
                        )
                    ) {
                        Text("Adicionar")
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Onde comprar jogos. Adicione, edite ou remova suas lojas.",
                    color = TextGray,
                    fontSize = 14.sp
                )
            }

            if (lojaViewModel.lojas.isEmpty()) {
                item {
                    Text("Nenhuma loja cadastrada. Toque em Adicionar.", color = TextGray)
                }
            }

            items(items = lojaViewModel.lojas, key = { it.id }) { loja ->
                CartaoLoja(
                    loja = loja,
                    aoEditar = {
                        lojaViewModel.limparErro()
                        lojaEditando = loja
                        mostrarDialogo = true
                    },
                    aoRemover = { lojaRemovendo = loja },
                    aoAbrirMapa = {
                        val abriu = abrirNoMapa(contexto, loja.endereco)
                        if (!abriu) lojaViewModel.avisar("Nenhum aplicativo de mapas encontrado.")
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (mostrarDialogo) {
        DialogoLoja(
            lojaViewModel = lojaViewModel,
            loja = lojaEditando,
            aoFechar = { mostrarDialogo = false }
        )
    }

    lojaRemovendo?.let { loja ->
        AlertDialog(
            onDismissRequest = { lojaRemovendo = null },
            containerColor = CardDark,
            titleContentColor = Color.White,
            textContentColor = TextGray,
            title = { Text("Remover loja?") },
            text = { Text("Remover \"${loja.nome}\" da sua lista de lojas?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        lojaViewModel.remover(loja.id)
                        lojaRemovendo = null
                    }
                ) { Text("Remover", color = VermelhoRemover) }
            },
            dismissButton = {
                TextButton(onClick = { lojaRemovendo = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun CartaoLoja(
    loja: Loja,
    aoEditar: () -> Unit,
    aoRemover: () -> Unit,
    aoAbrirMapa: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        elevation = CardDefaults.cardElevation(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                FotoLoja(
                    fotoArquivo = loja.fotoArquivo,
                    descricao = "Foto da loja ${loja.nome}",
                    modifier = Modifier
                        .size(88.dp)
                        .clip(RoundedCornerShape(12.dp))
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = loja.nome.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = loja.endereco, color = TextGray, fontSize = 13.sp)
                    if (loja.descricao.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = loja.descricao, color = Color.White, fontSize = 13.sp)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = aoAbrirMapa) { Text("Mapa") }
                TextButton(onClick = aoEditar) { Text("Editar") }
                TextButton(onClick = aoRemover) { Text("Remover", color = VermelhoRemover) }
            }
        }
    }
}

@Composable
private fun DialogoLoja(
    lojaViewModel: LojaViewModel,
    loja: Loja?,
    aoFechar: () -> Unit
) {
    var nome by remember { mutableStateOf(loja?.nome ?: "") }
    var endereco by remember { mutableStateOf(loja?.endereco ?: "") }
    var descricao by remember { mutableStateOf(loja?.descricao ?: "") }
    var foto by remember { mutableStateOf<Uri?>(null) }

    val seletorDeImagem = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) foto = uri
    }

    LaunchedEffect(lojaViewModel.concluido) {
        if (lojaViewModel.concluido) {
            lojaViewModel.consumirConclusao()
            aoFechar()
        }
    }

    AlertDialog(
        onDismissRequest = aoFechar,
        containerColor = CardDark,
        titleContentColor = Color.White,
        textContentColor = TextGray,
        title = { Text(if (loja == null) "Nova loja" else "Editar loja") },
        text = {
            Column {
                OutlinedTextField(
                    value = nome,
                    onValueChange = { if (it.length <= 100) nome = it },
                    label = { Text("Nome da loja") },
                    singleLine = true,
                    colors = coresDoCampo(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = endereco,
                    onValueChange = { if (it.length <= 200) endereco = it },
                    label = { Text("Endereço") },
                    minLines = 2,
                    colors = coresDoCampo(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = descricao,
                    onValueChange = { if (it.length <= 200) descricao = it },
                    label = { Text("O que vende") },
                    minLines = 2,
                    colors = coresDoCampo(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        seletorDeImagem.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PurpleAccent,
                        contentColor = Color.White
                    )
                ) {
                    Text(if (foto == null && loja?.fotoArquivo == null) "Escolher foto" else "Trocar foto")
                }
                if (foto != null) {
                    Text("Foto selecionada.", color = TextGray, fontSize = 13.sp)
                }
                lojaViewModel.erro?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (loja == null) {
                        lojaViewModel.adicionar(nome, endereco, descricao, foto)
                    } else {
                        lojaViewModel.atualizar(loja.id, nome, endereco, descricao, foto)
                    }
                },
                enabled = !lojaViewModel.processando
            ) { Text("Salvar") }
        },
        dismissButton = {
            TextButton(onClick = aoFechar) { Text("Cancelar") }
        }
    )
}

private fun abrirNoMapa(contexto: Context, endereco: String): Boolean {
    val destino = Uri.parse("geo:0,0?q=" + Uri.encode(endereco))
    return try {
        contexto.startActivity(Intent(Intent.ACTION_VIEW, destino))
        true
    } catch (e: ActivityNotFoundException) {
        false
    }
}
