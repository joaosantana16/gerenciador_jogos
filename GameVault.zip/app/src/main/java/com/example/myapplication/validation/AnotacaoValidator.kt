package com.example.myapplication.validation

object AnotacaoValidator {

    fun validar(texto: String) {
        require(texto.trim().length in 1..500) {
            "Escreva uma anotação de até 500 caracteres."
        }
    }
}
