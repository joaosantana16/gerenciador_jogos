package com.example.myapplication.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.myapplication.R
import com.example.myapplication.ui.theme.CardDark
import com.example.myapplication.ui.theme.TextGray
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ImagemCapa(
    capa: Int?,
    capaArquivo: String?,
    descricao: String,
    modifier: Modifier = Modifier
) {
    if (capaArquivo != null) {
        ImagemDeArquivo(caminho = capaArquivo, descricao = descricao, modifier = modifier)
    } else if (capa != null) {
        Image(
            painter = painterResource(id = capa),
            contentDescription = descricao,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier.background(CardDark),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_image),
                contentDescription = descricao,
                tint = TextGray
            )
        }
    }
}

@Composable
private fun ImagemDeArquivo(caminho: String, descricao: String, modifier: Modifier) {

    val imagem by produceState<ImageBitmap?>(null, caminho) {
        value = withContext(Dispatchers.IO) {
            BitmapFactory.decodeFile(caminho)?.asImageBitmap()
        }
    }

    val pronta = imagem
    if (pronta != null) {
        Image(
            bitmap = pronta,
            contentDescription = descricao,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(modifier = modifier.background(CardDark))
    }
}
