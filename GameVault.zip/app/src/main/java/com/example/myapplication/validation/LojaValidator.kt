package com.example.myapplication.validation

object LojaValidator {

    fun validar(nome: String, endereco: String, descricao: String) {
        require(nome.trim().length in 2..100) {
            "Informe o nome da loja (de 2 a 100 caracteres)."
        }
        require(endereco.trim().length in 5..200) {
            "Informe o endereço da loja (de 5 a 200 caracteres)."
        }
        require(descricao.trim().length <= 200) {
            "A descrição pode ter no máximo 200 caracteres."
        }
    }
}
