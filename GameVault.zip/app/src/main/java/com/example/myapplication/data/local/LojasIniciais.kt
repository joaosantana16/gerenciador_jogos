package com.example.myapplication.data.local

import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase

internal object LojasIniciais {
    private class Modelo(
        val nome: String,
        val endereco: String,
        val descricao: String
    )

    private val modelos = listOf(
        Modelo(
            "Santos Games e Lan House",
            "R. Rubem Berta, 200 - Pinheirinho, Curitiba - PR, 81150-311",
            "Vende games e eletrônicos: controles, teclados e fones"
        ),
        Modelo(
            "Street Games",
            "Rua Barão do Serro Azul, 229 - Centro, Curitiba - PR, 80020-180",
            "Artigos para jogos e aluguel de games"
        ),
        Modelo(
            "Nitro Internet e Games",
            "Av. Nossa Senhora de Lourdes, 957, Loja 01 - Jardim das Américas, Curitiba - PR, 81530-020",
            "Lan house e games"
        )
    )

    fun inserirPara(db: SQLiteDatabase, usuarioId: Long) {
        for (modelo in modelos) {
            val valores = ContentValues().apply {
                put("usuario_id", usuarioId)
                put("nome", modelo.nome)
                put("endereco", modelo.endereco)
                put("descricao", modelo.descricao)
            }
            db.insertOrThrow("lojas", null, valores)
        }
    }

    fun inserirParaTodos(db: SQLiteDatabase) {
        val ids = mutableListOf<Long>()
        db.rawQuery("SELECT id FROM usuarios", null).use { cursor ->
            while (cursor.moveToNext()) ids.add(cursor.getLong(0))
        }
        ids.forEach { inserirPara(db, it) }
    }
}
