package com.example.myapplication.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavHostController
import androidx.navigation.NavOptionsBuilder
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.toRoute
import com.example.myapplication.auth.SessaoUsuario
import com.example.myapplication.ui.screens.BibliotecaScreen
import com.example.myapplication.ui.screens.CadastroScreen
import com.example.myapplication.ui.screens.DetalhesJogoScreen
import com.example.myapplication.ui.screens.FormularioJogoScreen
import com.example.myapplication.ui.screens.InicioScreen
import com.example.myapplication.ui.screens.LoginScreen
import com.example.myapplication.ui.screens.LojasScreen
import com.example.myapplication.ui.screens.PerfilScreen
import com.example.myapplication.ui.viewmodel.JogoViewModel
import com.example.myapplication.ui.viewmodel.LojaViewModel

val opcoesDeAba: NavOptionsBuilder.() -> Unit = {
    popUpTo(Inicio) { inclusive = false }
    launchSingleTop = true
}

fun NavHostController.sair() {
    SessaoUsuario.encerrar()
    navigate(Login) {
        popUpTo(0) { inclusive = true }
    }
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    jogoViewModel: JogoViewModel,
    lojaViewModel: LojaViewModel,
    modifier: Modifier = Modifier
) {
    val entradaAtual by navController.currentBackStackEntryAsState()
    val destino = entradaAtual?.destination
    val usuarioAtual = SessaoUsuario.usuarioId

    LaunchedEffect(destino, usuarioAtual) {
        val publica = destino?.hasRoute<Login>() == true ||
                destino?.hasRoute<Cadastro>() == true

        if (destino != null && !publica && usuarioAtual == null) {
            navController.navigate(Login) {
                popUpTo(0) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Login,
        modifier = modifier
    ) {
        composable<Login> {
            LoginScreen(
                loginSucesso = {
                    navController.navigate(Inicio) {
                        popUpTo(Login) { inclusive = true }
                    }
                },
                irCadastro = { navController.navigate(Cadastro) },
                authViewModel = viewModel()
            )
        }

        composable<Cadastro> {
            CadastroScreen(
                irLogin = { navController.popBackStack() },
                authViewModel = viewModel()
            )
        }

        composable<Inicio> {
            InicioScreen(
                jogoViewModel = jogoViewModel,
                abrirDetalhes = { id -> navController.navigate(DetalhesJogo(id)) }
            )
        }

        composable<Biblioteca> {
            BibliotecaScreen(
                jogoViewModel = jogoViewModel,
                abrirDetalhes = { id -> navController.navigate(DetalhesJogo(id)) }
            )
        }

        composable<DetalhesJogo> { entrada ->
            val rota = entrada.toRoute<DetalhesJogo>()
            DetalhesJogoScreen(
                jogoId = rota.id,
                jogoViewModel = jogoViewModel,
                anotacaoViewModel = viewModel(),
                irParaEdicao = { id -> navController.navigate(EditarJogo(id)) },
                voltar = { navController.popBackStack() }
            )
        }

        composable<AdicionarJogo> {
            FormularioJogoScreen(
                jogoViewModel = jogoViewModel,
                jogoId = null,
                aoSalvar = { navController.navigate(Biblioteca, opcoesDeAba) }
            )
        }

        composable<EditarJogo> { entrada ->
            val rota = entrada.toRoute<EditarJogo>()
            FormularioJogoScreen(
                jogoViewModel = jogoViewModel,
                jogoId = rota.id,
                aoSalvar = { navController.popBackStack() }
            )
        }

        composable<Lojas> {
            LojasScreen(lojaViewModel = lojaViewModel)
        }

        composable<Perfil> {
            PerfilScreen(
                jogoViewModel = jogoViewModel,
                perfilViewModel = viewModel(),
                desejoViewModel = viewModel(),
                aoSair = { navController.sair() }
            )
        }
    }
}
