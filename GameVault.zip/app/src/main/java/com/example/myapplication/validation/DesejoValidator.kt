package com.example.myapplication.validation

object DesejoValidator {

    fun validar(titulo: String, plataforma: String, prioridade: Int) {
        require(titulo.trim().length in 2..100) {
            "Informe o nome do jogo (de 2 a 100 caracteres)."
        }
        require(plataforma.isNotBlank()) {
            "Escolha a plataforma."
        }
        require(prioridade in 1..3) {
            "Escolha a prioridade."
        }
    }
}
